#include <stdio.h>
#include <iostream>
#include <string.h>

using namespace std;

enum TokenType {
    NAME,
    EQUAL,
    ZERO,
    COLON,
    NAMESPACE_OPERATOR,
    OPEN_PARENTHESES,
    CLOSE_PARENTHESES,
    OPEN_CURLY,
    CLOSE_CURLY,
    COMMA,
    SEMICOLON,
    SPACE,
    LITERAL,
    STAR,
    OPEN_SQUARE,
    CLOSE_SQUARE,
    INT,/*
    SINGLE_LINE_COMMENT_SECTION,
    COMMENT_SECTION,*/
    UNDEFINED
};

struct Token {
    TokenType type;
    int beginIndex;
    int line;
    char token[100];
    int ordinal;

    Token() {
        type = SPACE;
    }

    Token(TokenType type1, int begin, int line1, int ordinal1) : type(type1), beginIndex(begin), line(line1), ordinal(ordinal1) {}
};

Token* tokens;
int tokenCount = 1;
int line = 1;
int character = 1;

Token* lastToken() {
    return &tokens[tokenCount - 1];
}

void newToken(TokenType type) {
    if(SPACE == lastToken()->type) {
        lastToken()->type = type;
        lastToken()->line = line;
        lastToken()->beginIndex = character;
        return;
    }
    tokens = (Token*) realloc(tokens, sizeof(Token) * (tokenCount + 1));
    tokens[tokenCount] = Token(type, character, line, tokenCount);
    tokenCount++;
}

void newUndefinedToken(char current) {
        if(UNDEFINED == lastToken()->type) return;
        newToken(UNDEFINED);
        lastToken()->token[character - lastToken()->beginIndex] = current;
        lastToken()->token[character - lastToken()->beginIndex + 1] = '\0';
}

void tokenize() {
    tokens = (Token*) calloc(1, sizeof(Token));
    FILE* file;
    file = fopen("input.txt", "r");
//	fopen_s(&file, "input.txt", "r");
    char current;
    while (true) {
        current = fgetc(file);
        character++;
        if (current == '\0' || current == EOF) {
            break;
        }
        if (current == '\n') {
            line++;
            character = 1;
        }

        if (lastToken()->type == LITERAL) {
            if (current == '"') {
                if(lastToken()->token[character - lastToken()->beginIndex - 1] != '\\') lastToken()->type = UNDEFINED;
            }
        } else if (current == '\n' || isspace(current)) {
            if (tokens[tokenCount - 1].type == SPACE) {
                continue;
            } else {
                newToken(SPACE);
            }
        } else if (current >= '0' && current <= '9') {
            if (tokens[tokenCount - 1].type != NAME) newToken(INT);
        } else if (current == ';') {
            newToken(SEMICOLON);
        } else if (current == ':') {
            if(lastToken()->type == COLON) {
                lastToken()->type = NAMESPACE_OPERATOR;
            } else newToken(COLON);
        } else if (current == '=') {
            newToken(EQUAL);
        } else if (current == '0') {
            newToken(ZERO);
        } else if (current == '*') {
            newToken(STAR);
        } else if (current == ',') {
            newToken(COMMA);
        } else if (current == '[') {
            newToken(OPEN_SQUARE);
        } else if (current == ']') {
            newToken(CLOSE_SQUARE);
        } else if (current == '(') {
            newToken(OPEN_PARENTHESES);
        } else if (current == ')') {
            newToken(CLOSE_PARENTHESES);
        } else if (current == '{') {
            newToken(OPEN_CURLY);
        } else if (current == '}') {
            newToken(CLOSE_CURLY);
        } else if (current == '"') {
            newToken(LITERAL);
        } else if (isalpha(current) || current == '_') {
            if (tokens[tokenCount - 1].type == NAME) {
            } else {
                newToken(NAME);
            }
        } else {
            newUndefinedToken(current);
            continue;
        }
            lastToken()->token[character - lastToken()->beginIndex] = current;
            lastToken()->token[character - lastToken()->beginIndex + 1] = '\0';
    }
    fclose(file);
}

enum structType {
    UNDEF,
    FUNCTION,
    PROTOTYPE
};

char z = '\0';
struct Structure {
    int begin;
    int end;
    structType type;
    char* funcName;
    char** retType;
    int rettypesize = 0;
    char** params;
    int paramSize;
    Structure(int beg, int e, structType t) : begin(beg), end(e), type(t) {
        retType = (char**)calloc(1, sizeof(char*));
        params = (char**)calloc(1, sizeof(char*));
        params[0] = &z;
        paramSize = 0;
    }

    int areParamsSimilar(Structure other);

    int isRettypeSimilar(Structure other);

    int issimilar(Structure other);

    void addRettype(char* name) {
        retType = (char**) realloc(retType, sizeof(char*) * (rettypesize + 1));
        retType[rettypesize++] = name;
    }

    void addParam(char* name) {
        params = (char**) realloc(params, sizeof(char*) * (paramSize + 1));
        params[paramSize++] = name;
    }
};
int Structure::areParamsSimilar(Structure other) {
    if(paramSize!=other.paramSize) return 0;
    for (int i = 0; i < paramSize; ++i) {
        if(strcmp(params[i], other.params[i])) return 0;
    }
    return 1;
}

int Structure::isRettypeSimilar(Structure other) {
    if(rettypesize!=other.rettypesize) return 0;
    for (int i = 0; i < rettypesize; ++i) {
        if(strcmp(retType[i], other.retType[i])) return 0;
    }
    return 1;
}

int Structure::issimilar(Structure other) {
    return !strcmp(funcName, other.funcName) && areParamsSimilar(other);
}

Structure *structs;
int fcount = 0;

int isFunc = 0;
int structBegin = 0;

void newStruct(int type, int current) {
    type *= isFunc;
    structs = (Structure*) realloc(structs, sizeof(Structure) * (fcount + 1));
    structs[fcount] = Structure(structBegin, current, (structType)type);
    fcount++;
    isFunc = 0;
    structBegin = current + 1;
}

void findStructs() {
    structs = (Structure*) calloc(1, sizeof(Structure));
    for (int i = 0; i < tokenCount - 1; i++){
        if(tokens[i].type == OPEN_PARENTHESES) {
            isFunc = 1;
            continue;
        } else if(tokens[i].type == OPEN_CURLY) {
            newStruct(FUNCTION, i);
        } else if(tokens[i].type == CLOSE_CURLY) {
            newStruct(FUNCTION, i);
        } else if(tokens[i].type == SEMICOLON) {
            newStruct(PROTOTYPE, i);
        } else continue;
    }
}

//  1 294 34 34 53 4 5600
//int a(a::b::a c, a g);{
//  1 2 12 1296 7 80
//int a::a::a() = 0;
enum State {
    EXP_RET_TYPE,                                                   // 1268->0->1
    EXP_FUNC_NAME_OR_NAMESPACE_OR_POINTER_OR_NAMESPACE_OPERATOR,                  //   02->1->02
    EXP_POINTER_OR_FUNC_NAME,
    EXP_NAMESPACE_OPERATOR_OR_OPEN_PARENTHESES,    //    1->2->019
    EXP_NAMESPACE_OR_PARAM_TYPE,                            //   45->3->4
    EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME,                   //    3->4->35
    EXP_COMMA_OR_CLOSE_PARENTHESES,                         //    4->5->36
    EXP_OPEN_CURLY_OR_SEMICOLON_OR_EQUAL,                   //   35->6->07
    EXP_ZERO,                                               //    6->7->8
    EXP_SEMICOLON,                                          //    7->8->0
    EXP_NAMESPACE_OR_PARAM_TYPE_OR_CLOSE_PARENTHESES,       //    2->9->46
    EXP_INT,
    EXP_INT_OR_CLOSE_SQUARE,
    EXP_FUNC_NAME_OR_NAMESPACE,
    EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME_OR_COMMA_OR_CLOSE_PARENTHERSES
};

State state = EXP_RET_TYPE;
int problems = 0;//todo rm on ; or }

FILE* out;

void announceProblem(int index) {
    Token token = tokens[index];
    const char* expected = "";
    switch (state) {
    case EXP_RET_TYPE:
        expected = "return type";
        break;
    case EXP_POINTER_OR_FUNC_NAME:
    case EXP_FUNC_NAME_OR_NAMESPACE_OR_POINTER_OR_NAMESPACE_OPERATOR:
        expected = "function name";
        break;
    case EXP_NAMESPACE_OPERATOR_OR_OPEN_PARENTHESES:
        expected = "'('";
        break;
    case EXP_NAMESPACE_OR_PARAM_TYPE:
        expected = "parameter type";
        break;
    case EXP_NAMESPACE_OR_PARAM_TYPE_OR_CLOSE_PARENTHESES:
        expected = "')' or parameter type";
        break;
    case EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME:
        expected = "parameter name";
        break;
    case EXP_COMMA_OR_CLOSE_PARENTHESES:
        expected = "',' or ')'";
        break;
    case EXP_OPEN_CURLY_OR_SEMICOLON_OR_EQUAL:
        expected = "'{' or ';' or '= 0;'";
        break;
    case EXP_ZERO:
        expected = "'0'";
        break;
    case EXP_SEMICOLON:
        expected = "';'";
        break;
    case EXP_FUNC_NAME_OR_NAMESPACE:
        expected = "function name";
        break;
    case EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME_OR_COMMA_OR_CLOSE_PARENTHERSES:
        expected = "',' or ')' or parameter name";
        break;
    default:
        printf("impossible state\n");
        break;
    }
    fprintf(out, "Problem at line %d at character %d. Expected %s, found '%s'\n", token.line, token.beginIndex,
            expected, token.token);
    printf("Problem at line %d at character %d. Expected %s, found '%s'\n", token.line, token.beginIndex,
           expected, token.token);
    problems++;
    state = EXP_RET_TYPE;
}

void checkFunctionLinkage() {
    problems = 0;
    for (int i = 0; i < fcount; ++i) {
        switch (structs[i].type) {
        case UNDEF:
            continue;
        case FUNCTION:
            for (int j = 0; j < i; ++j) {
                switch (structs[j].type) {
                case UNDEF:
                    continue;
                case FUNCTION:
                    if (structs[j].issimilar(structs[i])) {
                        problems++;
                        fprintf(out, "Problem at line %d at character %d. Function was already declared\n",
                             tokens[structs[i].begin].line, tokens[structs[i].begin].beginIndex);
                        printf("Problem at line %d at character %d. Function was already declared\n",
                             tokens[structs[i].begin].line, tokens[structs[i].begin].beginIndex);
                        structs[j].type = UNDEF;
                    }
                    break;
                case PROTOTYPE:
                    break;
                }
            }
            break;
        case PROTOTYPE:
            int hasImpl = 0;
            for (int j = 0; j < fcount; ++j) {
                if (i==j) continue;
                switch (structs[j].type) {
                case UNDEF:
                    continue;
                case FUNCTION:
                    if (structs[j].issimilar(structs[i])) if(!structs[j].isRettypeSimilar(structs[i])) {
                        problems++;
                        fprintf(out, "Problem at line %d at character %d. Wrong return type\n",
                                  tokens[structs[i].begin].line, tokens[structs[i].begin].beginIndex);
                        printf("Problem at line %d at character %d. Wrong return type\n",
                                  tokens[structs[i].begin].line, tokens[structs[i].begin].beginIndex);
                        hasImpl = 1;
                    }else hasImpl = 1;
                    break;
                case PROTOTYPE:
                    if (structs[j].issimilar(structs[i])) if(!structs[j].isRettypeSimilar(structs[i])) {
                        problems++;
                        fprintf(out, "Problem at line %d at character %d. Wrong return type\n",
                                  tokens[structs[i].begin].line, tokens[structs[i].begin].beginIndex);
                        printf("Problem at line %d at character %d. Wrong return type\n",
                                  tokens[structs[i].begin].line, tokens[structs[i].begin].beginIndex);
                    }
                    break;
                }
            }
            if(!hasImpl) {
                problems++;
                fprintf(out, "Problem at line %d at character %d. Function is not implemented\n",
                                    tokens[structs[i].begin].line, tokens[structs[i].begin].beginIndex);
            printf("Problem at line %d at character %d. Function is not implemented\n",
                                tokens[structs[i].begin].line, tokens[structs[i].begin].beginIndex);
            }
            break;
        }
    }
}

int main() {
    tokenize();
    findStructs();

    int hasProblems = 0;

    out = fopen("output.txt", "w");

    for (int j = 0; j < fcount; j++){
        if (structs[j].type == UNDEF) continue;
        for (int i = structs[j].begin; i <= structs[j].end;++i) {
            switch (state) {
            case EXP_RET_TYPE:
                if (tokens[i].type == NAME) {
                    structs[j].addRettype(&(tokens[i].token[0]));
                    state = EXP_FUNC_NAME_OR_NAMESPACE_OR_POINTER_OR_NAMESPACE_OPERATOR;
                } else announceProblem(i);
                break;
            case EXP_FUNC_NAME_OR_NAMESPACE_OR_POINTER_OR_NAMESPACE_OPERATOR:
                if (tokens[i].type == STAR) {
                    state = EXP_POINTER_OR_FUNC_NAME;
                    structs[j].addRettype(&(tokens[i].token[0]));
                } else if (tokens[i].type == NAMESPACE_OPERATOR) {
                    state = EXP_RET_TYPE;
                } else if (tokens[i].type == NAME) {
                    state = EXP_NAMESPACE_OPERATOR_OR_OPEN_PARENTHESES;
                    structs[j].funcName = &(tokens[i].token[0]);
                } else announceProblem(i);
                break;
            case EXP_FUNC_NAME_OR_NAMESPACE:
                if (tokens[i].type == NAME) {
                    state = EXP_NAMESPACE_OPERATOR_OR_OPEN_PARENTHESES;
                    structs[j].funcName = &(tokens[i].token[0]);
                } else announceProblem(i);
                break;
            case EXP_POINTER_OR_FUNC_NAME:
                if (tokens[i].type == STAR) {
                    structs[j].addRettype(&(tokens[i].token[0]));
                } else if (tokens[i].type == NAME) {
                    structs[j].funcName = &(tokens[i].token[0]);
                    state = EXP_NAMESPACE_OPERATOR_OR_OPEN_PARENTHESES;
                } else announceProblem(i);
                break;
            case EXP_NAMESPACE_OPERATOR_OR_OPEN_PARENTHESES:
                if(tokens[i].type == NAMESPACE_OPERATOR) {
                    state = EXP_FUNC_NAME_OR_NAMESPACE;
                } else if(tokens[i].type == OPEN_PARENTHESES) {
                    state = EXP_NAMESPACE_OR_PARAM_TYPE_OR_CLOSE_PARENTHESES;
                } else announceProblem(i);
                break;
            case EXP_NAMESPACE_OR_PARAM_TYPE_OR_CLOSE_PARENTHESES:
                if(tokens[i].type == NAME) {
                    if(structs[j].type == FUNCTION) state = EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME;
                    else state = EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME_OR_COMMA_OR_CLOSE_PARENTHERSES;
                    structs[j].addParam(&(tokens[i].token[0]));
                } else if(tokens[i].type == CLOSE_PARENTHESES) {
                    state = EXP_OPEN_CURLY_OR_SEMICOLON_OR_EQUAL;
                } else announceProblem(i);
                break;
            case EXP_NAMESPACE_OR_PARAM_TYPE:
                if(tokens[i].type == NAME) {
                    structs[j].addParam(&(tokens[i].token[0]));
                    if(structs[j].type == FUNCTION) state = EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME;
                    else state = EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME_OR_COMMA_OR_CLOSE_PARENTHERSES;
                } else announceProblem(i);
                break;
            case EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME_OR_COMMA_OR_CLOSE_PARENTHERSES:
                if(tokens[i].type == NAMESPACE_OPERATOR) {
                    structs[j].addParam(&(tokens[i].token[0]));
                    state = EXP_NAMESPACE_OR_PARAM_TYPE;
                } else if(tokens[i].type == NAME) {
                    state = EXP_COMMA_OR_CLOSE_PARENTHESES;
                } else if(tokens[i].type == COMMA) {
                    state = EXP_NAMESPACE_OR_PARAM_TYPE;
                } else if(tokens[i].type == CLOSE_PARENTHESES) {
                    state = EXP_OPEN_CURLY_OR_SEMICOLON_OR_EQUAL;
                } else announceProblem(i);
                break;
            case EXP_NAMESPACE_OPERATOR_OR_PARAM_NAME:
                if(tokens[i].type == NAMESPACE_OPERATOR) {
                    structs[j].addParam(&(tokens[i].token[0]));
                    state = EXP_NAMESPACE_OR_PARAM_TYPE;
                } else if(tokens[i].type == NAME) {
                    state = EXP_COMMA_OR_CLOSE_PARENTHESES;
                } else announceProblem(i);
                break;
            case EXP_COMMA_OR_CLOSE_PARENTHESES:
                if(tokens[i].type == COMMA) {
                    state = EXP_NAMESPACE_OR_PARAM_TYPE;
                } else if(tokens[i].type == CLOSE_PARENTHESES) {
                    state = EXP_OPEN_CURLY_OR_SEMICOLON_OR_EQUAL;
                } else announceProblem(i);
                break;
            case EXP_OPEN_CURLY_OR_SEMICOLON_OR_EQUAL:
                if(tokens[i].type == OPEN_CURLY) {
                    state = EXP_RET_TYPE;
                } else if(tokens[i].type == SEMICOLON) {
                    state = EXP_RET_TYPE;
                } else if(tokens[i].type == EQUAL) {
                    state = EXP_ZERO;
                    structs[j].type = FUNCTION;
                } else announceProblem(i);
                break;
            case EXP_ZERO:
                if(tokens[i].type == INT&&tokens[i].token[0]=='0') {
                    state = EXP_SEMICOLON;
                } else announceProblem(i);
                break;
            case EXP_SEMICOLON:
                if(tokens[i].type == SEMICOLON) {
                    state = EXP_RET_TYPE;
                } else announceProblem(i);
                break;
            default:
                break;
            }
            if(problems) {
                hasProblems++;
                problems = 0;
                break;
            }
        }
    }
checkFunctionLinkage();
    if (!hasProblems && !problems) {
        fprintf(out, "OK\n");
        printf("OK\n");
    }
    fclose(out);
    return 0;
}
