echo "compiling..."
./compile.sh
echo "running..."
./run.sh
