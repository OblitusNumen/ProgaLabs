g++ ./main.cpp
read a
