./a.out
read a
