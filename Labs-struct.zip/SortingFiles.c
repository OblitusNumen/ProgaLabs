#include <stdio.h>
#include <stdlib.h>

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
    #define CLEAR system("cls");
    #define scanf scanf_s
    #define open(file, name, mode) fopen_s(&file, name, mode);
#else
    #define CLEAR system("clear -x");
    #define open(file, name, mode) file = fopen(name, mode);
#endif

int main() {
    FILE* input;
    open(input, "input.txt", "r");
    FILE* output;
    open(output, "output.txt", "w");
    FILE* left;
    FILE* right;
    int count = 0;
    int num;
    fscanf(input, "%d", &num);
    while (!feof(input)) {
        fprintf(output, "%d ", num);
        count++;
        fscanf(input, "%d", &num);
    }
    fclose(input);
    fclose(output);
    for (int i = 1; i < count; i*=2) {
        open(output, "output.txt", "r");
        open(left, "left.txt", "w");
        open(right, "right.txt", "w");
        fscanf(output, "%d", &num);
        for (int j = 0; j < count; ++j) {
            fprintf(j / i % 2 == 0 ? left : right, "%d ", num);
            fscanf(output, "%d", &num);
        }
        fclose(output);
        fclose(left);
        fclose(right);
        int num1;
        int num2;
        open(output, "output.txt", "w");
        open(left, "left.txt", "r");
        open(right, "right.txt", "r");
        fscanf(left, "%d", &num1);
        fscanf(right, "%d", &num2);
        while (1) {
            int c1 = 0;
            int c2 = 0;
            while (c1 < i && c2 < i) {
                if (num2 < num1) {
                    fprintf(output, "%d ", num2);
                    ++c2;
                    fscanf(right, "%d", &num2);
                    if (feof(right)) break;
                } else {
                    fprintf(output, "%d ", num1);
                    ++c1;
                    fscanf(left, "%d", &num1);
                    if (feof(left)) break;
                }
            }
            while (!feof(right) && c2 < i) {
                fprintf(output, "%d ", num2);
                ++c2;
                fscanf(right, "%d", &num2);
            }
            while (!feof(left) && c1 < i) {
                fprintf(output, "%d ", num1);
                ++c1;
                fscanf(left, "%d", &num1);
            }
            if (feof(left) && feof(right)) break;
        }
        fclose(output);
        fclose(left);
        fclose(right);
    }
    return 0;
}
