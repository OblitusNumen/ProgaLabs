#include <stdio.h>
#include <stdlib.h>

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
    #define CLEAR system("cls");
#else
    #define CLEAR system("clear -x");
#endif

struct node {
    struct node* prev;
    char value;
    struct node* next;
};

struct DoublyLinkedList {
    struct node* zeroptr;
    struct node* currptr;
    struct node* lastptr;
};

void init(struct DoublyLinkedList* list) {
    list->zeroptr = 0;
    list->lastptr = 0;
    list->currptr = 0;
}

void printUpFrom(struct DoublyLinkedList list, struct node* printFrom) {
    while (printFrom != 0) {
        if (printFrom == list.currptr) printf(">%c< ", printFrom->value);
        else printf("%c ", printFrom->value);
        printFrom = printFrom->next;
    }
    printf("\n");
}

void printDownFrom(struct DoublyLinkedList list, struct node* printFrom) {
    while (printFrom != 0) {
        if (printFrom == list.currptr) printf(">%c< ", printFrom->value);
        else printf("%c ", printFrom->value);
        printFrom = printFrom->prev;
    }
    printf("\n");
}

void print(struct DoublyLinkedList list) {
    printf("Direct order: ");
    printUpFrom(list, list.zeroptr);
    printf("Reverse order: ");
    printDownFrom(list, list.lastptr);
}

void addAfter(struct DoublyLinkedList* list, char value) {
    struct node* newNode = (struct node*) malloc(sizeof(struct node));
    if(newNode == 0) {
        printf("Couldn't allocate memory for new node");
        return;
    }
    newNode->value = value;
    newNode->prev = list->currptr;
    newNode->next = 0;
    if (list->currptr == 0) {
        list->zeroptr = newNode;
        list->currptr = newNode;
        list->lastptr = newNode;
        return;
    }
    newNode->next = list->currptr->next;
    if (list->currptr == list->lastptr) {
        list->lastptr = newNode;
    } else {
        list->currptr->next->prev = newNode;
    }
    list->currptr->next = newNode;
}

void addBefore(struct DoublyLinkedList* list, char value) {
    struct node* newNode = (struct node*) malloc(sizeof(struct node));
    if(newNode == 0) {
        printf("Couldn't allocate memory for new node");
        return;
    }
    newNode->value = value;
    newNode->prev = 0;
    newNode->next = list->currptr;
    if (list->currptr == 0) {
        list->zeroptr = newNode;
        list->currptr = newNode;
        list->lastptr = newNode;
        return;
    }
    newNode->prev = list->currptr->prev;
    if (list->currptr == list->zeroptr) {
        list->zeroptr = newNode;
    } else {
        list->currptr->prev->next = newNode;
    }
    list->currptr->prev = newNode;
}

void rmAfter(struct DoublyLinkedList* list) {
    struct node* toFree;
    if (list->currptr == 0) {
        printf("List is already empty");
        return;
    }
    if (list->currptr->next == 0) {
        if (list->currptr->prev == 0) {
            toFree = list->currptr;
            list->zeroptr = 0;
            list->currptr = 0;
            list->lastptr = 0;
        } else return;
    } else {
        toFree = list->currptr->next;
        if (toFree == list->lastptr) list->lastptr = list->currptr;
        else toFree->next->prev = list->currptr;
        list->currptr->next = toFree->next;
    }
    free(toFree);
}

void rmBefore(struct DoublyLinkedList* list) {
    struct node* toFree;
    if (list->currptr == 0) {
        printf("List is already empty");
        return;
    }
    if (list->currptr->prev == 0) {
        if (list->currptr->next == 0) {
            toFree = list->currptr;
            list->zeroptr = 0;
            list->currptr = 0;
            list->lastptr = 0;
        } else return;
    } else {
        toFree = list->currptr->prev;
        if (toFree == list->zeroptr) list->zeroptr = list->currptr;
        else toFree->prev->next = list->currptr;
        list->currptr->prev = toFree->prev;
    }
    free(toFree);
}

void clear(struct DoublyLinkedList* list) {
    list->currptr = list->zeroptr;
    while(list->currptr != 0) {
        rmAfter(list);
    }
}

void moveptrAfter(struct DoublyLinkedList* list) {
    if (list->currptr != 0 && list->currptr->next != 0) {
        list->currptr = list->currptr->next;
    }
}

void moveptrBefore(struct DoublyLinkedList* list) {
    if (list->currptr != 0 && list->currptr->prev != 0) {
        list->currptr = list->currptr->prev;
    }
}

void printMenu() {
    printf("1) Initialize\n");
    printf("2) Clear list\n");
    printf("3) Is list empty\n");
    printf("4) Set pointer to first element\n");
    printf("5) Set pointer to last element\n");
    printf("6) Is pointer on the first element\n");
    printf("7) Is pointer on the last element\n");
    printf("8) Move pointer to the right\n");
    printf("9) Move pointer to the left\n");
    printf("10) Show value before pointer\n");
    printf("11) Show value after pointer\n");
    printf("12) Remove element before pointer\n");
    printf("13) Remove element after pointer\n");
    printf("14) Save value before pointer\n");
    printf("15) Save value after pointer\n");
    printf("16) Edit element before pointer\n");
    printf("17) Edit element after pointer\n");
    printf("18) Add element before pointer\n");
    printf("19) Add element after pointer\n");
    printf("20) Print list\n");
    printf("21) End work\n");
    printf("22) Stop program\n");
    printf("\nEnter command code: ");
}

void clearBuffer() {
    char c = getchar();
    while(c != '\n' && c != '\0' && c != EOF) {
        c = getchar();
    }
}

int main() {
    struct DoublyLinkedList list;
    int working = 0;
    int savedVal = 0;

    while(1) {
        printMenu();
        int cmd = 0;
        char c = getchar();
        while(c != '\n' && c != '\0' && c != EOF) {
            cmd = cmd * 10 + c - '0';
            c = getchar();
        }
        switch(cmd) {
        case 1:
            if (working) {
                printf("List is already initialized\n");
                break;
            }
            init(&list);
            working = 1;
            break;
        case 2:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            clear(&list);
            break;
        case 3:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.zeroptr == 0) printf("Yes\n");
            else printf("No\n");
            break;
        case 4:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            list.currptr = list.zeroptr;
            break;
        case 5:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            list.currptr = list.lastptr;
            break;
        case 6:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->prev == 0) printf("Yes\n");
            else printf("No\n");
            break;
        case 7:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->next == 0) printf("Yes\n");
            else printf("No\n");
            break;
        case 9:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            moveptrBefore(&list);
            break;
        case 8:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            moveptrAfter(&list);
            break;
        case 10:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->prev == 0) printf("NULL\n");
            else printf("%c\n", list.currptr->prev->value);
            break;
        case 11:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->next == 0) printf("NULL\n");
            else printf("%c\n", list.currptr->next->value);
            break;
        case 12:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            rmBefore(&list);
            break;
        case 13:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            rmAfter(&list);
            break;
        case 14:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr != 0 && list.currptr->prev != 0) savedVal = list.currptr->prev->value;
            break;
        case 15:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr != 0 && list.currptr->next != 0) savedVal = list.currptr->next->value;
            break;
        case 16:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->prev == 0) printf("No element before pointer\n");
            else {
                printf("Enter new value: ");
                list.currptr->prev->value = getchar();
                clearBuffer();
            }
            break;
        case 17:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->next == 0) printf("No element after pointer\n");
            else {
                printf("Enter new value: ");
                list.currptr->next->value = getchar();
                clearBuffer();
            }
            break;
        case 18:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            printf("Enter new element: ");
            addBefore(&list, getchar());
            clearBuffer();
            break;
        case 19:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            printf("Enter new element: ");
            addAfter(&list, getchar());
            clearBuffer();
            break;
        case 20:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            break;
        case 21:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            clear(&list);
            working = 0;
            break;
        case 22:
            goto label1;
            break;
        default:
            printf("No such command!\n");
        }
        if (working) print(list);
        printf("Press ENTER to continue");
        clearBuffer();
        CLEAR
    }
    label1:
    if (savedVal) printf("Saved value: %c\n", savedVal);
    return 0;
}
