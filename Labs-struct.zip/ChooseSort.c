#include <stdio.h>
#include <stdlib.h>

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
    #define CLEAR system("cls");
    #define scanf scanf_s;
#else
    #define CLEAR system("clear -x");
#endif

void printArr(int* aarr, int ccount) {
    static int* arr = 0;
    static int count = 0;
    if (!arr) {
        arr = aarr;
        count = ccount;
    }
    for (int i = 0; i < count; ++i) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

void choosingSort(int* arr, int count) {
    for (int i = 0; i < count - 1; ++i) {
        int minI = i;
        for (int j = i + 1; j < count; ++j) {
            if (arr[j] < arr[minI]) {
                minI = j;
            }
            printArr(0, 0);
        }
        int buff = arr[minI];
        arr[minI] = arr[i];
        arr[i] = buff;
    }
}

void insert(int* arr, int to, int from) {
    int buff = arr[from];
    for (int i = from; i > to; --i) {
        arr[i] = arr[i - 1];
    }
    arr[to] = buff;
}

int findIndex(int* arr, int from, int to, int compare) {
    if (from == to) return from + (arr[from] < compare);
    int center = (from + to) / 2;
    if (arr[center] < compare) return findIndex(arr, center + 1, to, compare);
    return findIndex(arr, from, center, compare);
}

void halfDivision(int* arr, int count) {
    for (int i = 1; i < count; ++i) {
        insert(arr, findIndex(arr, 0, i - 1, arr[i]), i);
        printArr(0, 0);
    }
}

void quickSort(int* arr, int count) {
    if (count <= 0) return;
    int lowI = 0;
    int highI = count - 2;
    while (lowI <= highI) {
        printArr(0, 0);
        if (arr[highI] > arr[highI + 1]) {
            int buff = arr[highI];
            arr[highI] = arr[highI + 1];
            arr[highI + 1] = buff;
            --highI;
            continue;
        }
        if (arr[lowI] > arr[highI]) {
            int buff = arr[lowI];
            arr[lowI] = arr[highI];
            arr[highI] = buff;
        }
        ++lowI;
    }
    quickSort(arr, lowI);
    quickSort(arr + lowI + 1, count - lowI - 1);
}

int main() {
    int arr[100];
    printf("Write number of elements: ");
    int count;
    scanf("%d", &count);
    printf("Write %d elements: ", count);
    for (int i = 0; i < count; ++i) {
        scanf("%d", arr + i);
    }
    int cmd;
    while (1) {
        printf("Choose sorting algorithm:\n");
        printf("\t1)Choosing sort\n");
        printf("\t2)Half division sort\n");
        printf("\t3)Quick sort\n");
        scanf("%d", &cmd);
        if (cmd >= 1 && cmd <= 3) break;
        printf("Wrong command!\n");
    }
    printf("Unsorted array: ");
    printArr(arr, count);
    switch (cmd) {
    case 1:
        choosingSort(arr, count);
        break;
    case 2:
        halfDivision(arr, count);
        break;
    case 3:
        quickSort(arr, count);
        break;
    }
    printf("Sorted array: ");
    printArr(arr, count);
    return 0;
}
