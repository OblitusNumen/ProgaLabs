#include <stdio.h>
#include <stdlib.h>

void copy(int from[], int to[], int begin, int size) {
    for (int i = 0; i < size; i++) {
        to[i] = from[begin + i];
    }
}

void sort(int a[], int begin, int end) {
    if (begin + 1 == end) return;
    int center = (begin + end) / 2;
    sort(a, begin, center);
    sort(a, center, end);
    
    int sizeFirst = center - begin;
    int first[sizeFirst];
    copy(a, first, begin, sizeFirst);
    
    int sizeSecond = end - center;
    int second[sizeSecond];
    copy(a, second, center, sizeSecond);
    
    int i = 0;
    int j = 0;
    while (i < sizeFirst && j < sizeSecond) {
        if (first[i] < second[j]) {
            a[begin + i + j] = first[i];
            i++;
        } else {
            a[begin + i + j] = second[j];
            j++;
        }
    }
    
    for (; i < sizeFirst; i++) {
        a[begin + i + j] = first[i];
    }
    
    for (; j < sizeSecond; j++) {
        a[begin + i + j] = second[j];
    }
}

void rin(int a[], int size) {
    for (int i = 0; i < size; i++) {
        a[i] = rand() - 65536;
    }
}

void in(int a[], int size) {
    for (int i = 0; i < size; i++) {
        scanf("%d", a + i);
    }
}

void out(int a[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d%c", a[i], i + 1 != size ? ' ' : '\n');
    }
}

int main() {
    int size;
    scanf("%d", &size);
    int a[size];
    rin(a, size);
    out(a, size);
    sort(a, 0, size);
    out(a, size);
    return 0;
}
