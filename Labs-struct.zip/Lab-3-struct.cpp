#include <stdio.h>
#include <stdlib.h>

struct node1 {
    char value;
    struct node1* next;
};

struct SinglyLinkedList {
    struct node1* zeroptr;
    struct node1* currptr;
};

void init(struct SinglyLinkedList* list) {
    list->zeroptr = 0;
    list->currptr = 0;
}

void addElement(struct SinglyLinkedList* list, char value) {
    struct node1* newNode = (struct node1*) malloc(sizeof(struct node1));
    if(newNode == 0) {
        printf("Couldn't allocate memory for new node");
        return;
    }
    newNode->value = value;
    newNode->next = 0;
    if (list->currptr == 0) {
        list->currptr = newNode;
        list->zeroptr = newNode;
        return;
    }
    newNode->next = list->currptr->next;
    list->currptr->next = newNode;
}

void rmElement(struct SinglyLinkedList* list) {
    struct node1* toFree;
    if (list->currptr == 0) {
        printf("List is already empty");
        return;
    }
    if (list->currptr->next == 0) {
        toFree = list->currptr;
        list->currptr = 0;
        list->zeroptr = 0;
    } else {
        toFree = list->currptr->next;
        list->currptr->next = toFree->next;
    }
    free(toFree);
}

void clear(struct SinglyLinkedList* list) {
    list->currptr = list->zeroptr;
    while(list->currptr != 0) {
        rmElement(list);
    }
}

void moveptr(struct SinglyLinkedList* list) {
    if (list->currptr != 0 && list->currptr->next != 0) {
        list->currptr = list->currptr->next;
    }
}

void printFrom(struct node1* printFrom) {
    while (printFrom != 0) {
        printf("%c", printFrom->value);
        printFrom = printFrom->next;
    }
    printf("\n");
}

void print(struct SinglyLinkedList list) {
    printFrom(list.zeroptr);
}

struct node2 {
    struct node2* prev;
    char value;
    struct node2* next;
};

struct DoublyLinkedList {
    struct node2* zeroptr;
    struct node2* currptr;
    struct node2* lastptr;
};

void init2(struct DoublyLinkedList* list) {
    list->zeroptr = 0;
    list->lastptr = 0;
    list->currptr = 0;
}

void printUpFrom(struct node2* printFrom) {
    while (printFrom != 0) {
        printf("%c", printFrom->value);
        printFrom = printFrom->next;
    }
}

void addAfter(struct DoublyLinkedList* list, char value) {
    struct node2* newNode = (struct node2*) malloc(sizeof(struct node2));
    if(newNode == 0) {
        printf("Couldn't allocate memory for new node");
        return;
    }
    newNode->value = value;
    newNode->prev = list->currptr;
    newNode->next = 0;
    if (list->currptr == 0) {
        list->zeroptr = newNode;
        list->currptr = newNode;
        list->lastptr = newNode;
        return;
    }
    newNode->next = list->currptr->next;
    if (list->currptr == list->lastptr) {
        list->lastptr = newNode;
    } else {
        list->currptr->next->prev = newNode;
    }
    list->currptr->next = newNode;
}

void addBefore(struct DoublyLinkedList* list, char value) {
    struct node2* newNode = (struct node2*) malloc(sizeof(struct node2));
    if(newNode == 0) {
        printf("Couldn't allocate memory for new node");
        return;
    }
    newNode->value = value;
    newNode->prev = 0;
    newNode->next = list->currptr;
    if (list->currptr == 0) {
        list->zeroptr = newNode;
        list->currptr = newNode;
        list->lastptr = newNode;
        return;
    }
    newNode->prev = list->currptr->prev;
    if (list->currptr == list->zeroptr) {
        list->zeroptr = newNode;
    } else {
        list->currptr->prev->next = newNode;
    }
    list->currptr->prev = newNode;
}

void rmAfter(struct DoublyLinkedList* list) {
    struct node2* toFree;
    if (list->currptr == 0) {
        printf("List is already empty");
        return;
    }
    if (list->currptr->next == 0) {
        if (list->currptr->prev == 0) {
            toFree = list->currptr;
            list->zeroptr = 0;
            list->currptr = 0;
            list->lastptr = 0;
        } else return;
    } else {
        toFree = list->currptr->next;
        if (toFree == list->lastptr) list->lastptr = list->currptr;
        else toFree->next->prev = list->currptr;
        list->currptr->next = toFree->next;
    }
    free(toFree);
}

void rmBefore(struct DoublyLinkedList* list) {
    struct node2* toFree;
    if (list->currptr == 0) {
        printf("List is already empty");
        return;
    }
    if (list->currptr->prev == 0) {
        if (list->currptr->next == 0) {
            toFree = list->currptr;
            list->zeroptr = 0;
            list->currptr = 0;
            list->lastptr = 0;
        } else return;
    } else {
        toFree = list->currptr->prev;
        if (toFree == list->zeroptr) list->zeroptr = list->currptr;
        else toFree->prev->next = list->currptr;
        list->currptr->prev = toFree->prev;
    }
    free(toFree);
}

void clear2(struct DoublyLinkedList* list) {
    list->currptr = list->zeroptr;
    while(list->currptr != 0) {
        rmAfter(list);
    }
}

void moveptrAfter(struct DoublyLinkedList* list) {
    if (list->currptr != 0 && list->currptr->next != 0) {
        list->currptr = list->currptr->next;
    }
}

void moveptrBefore(struct DoublyLinkedList* list) {
    if (list->currptr != 0 && list->currptr->prev != 0) {
        list->currptr = list->currptr->prev;
    }
}

void in(struct DoublyLinkedList* list) {
	while (true) {
		int c = getchar();
        if (c == '\n' || c == EOF || c == '\0') {
			break;
		}
		addAfter(list, c);
        moveptrAfter(list);
	}
    list->currptr = list->zeroptr;
}

void in1(struct SinglyLinkedList* list) {
	while (true) {
		int c = getchar();
        if (c == '\n' || c == EOF || c == '\0') {
			moveptr(list);
			break;
		}
		addElement(list, c);
        moveptr(list);
	}
    list->currptr = list->zeroptr;
}

void main1() {
    struct SinglyLinkedList list;
    init(&list);
    in1(&list);
    int aCount = 0;
    node1* wbegin = list.zeroptr;
    while (true) {
        if (list.currptr->value == ' ' || list.currptr->next == 0) {
            if (list.currptr->value == 'a') aCount++;
            if (aCount == 2) {
                list.currptr = wbegin;
                while (true) {
                    if (list.currptr->next == 0) break;
                    if (list.currptr->next->value == ' ') {
                        rmElement(&list);
                        break;
                    }
                    rmElement(&list);
                }
                if (list.currptr->value != ' ') {
                    moveptr(&list);
                    free(list.zeroptr);
                    list.zeroptr = list.currptr;
                }
            }
            if (list.currptr->next == 0) break;
            aCount = 0;
            wbegin = list.currptr;
        } else {
            if (list.currptr->value == 'a') aCount++;
        }
        moveptr(&list);
    }
    print(list);
    printf("\n");
    clear(&list);
}

void main2() {
	struct DoublyLinkedList list;
	init2(&list);
    in(&list);
    int aCount = 0;
    node2* wbegin = list.zeroptr;
    while (true) {
        if (list.currptr->value == ' ' || list.currptr == list.lastptr) {
            if (list.currptr->value == 'a') aCount++;
            if (aCount == 2) {
                list.currptr = wbegin;
                while (true) {
                    if (list.currptr == list.lastptr) break;
                    if (list.currptr->next->value == ' ') {
                        rmAfter(&list);
                        break;
                    }
                    rmAfter(&list);
                }
                if (list.currptr->value != ' ') {
                    moveptrAfter(&list);
                    rmBefore(&list);
                }
            }
            if (list.currptr == list.lastptr) break;
            aCount = 0;
            wbegin = list.currptr;
        } else {
            if (list.currptr->value == 'a') aCount++;
        }
        moveptrAfter(&list);
    }
    printUpFrom(list.zeroptr);
	printf("\n");
    clear2(&list);
}

int main() {
    //main2();
    main1();
	return 0;
}
