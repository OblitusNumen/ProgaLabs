#include <stdio.h>
#include <stdlib.h>

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
    #define CLEAR system("cls");
    #define scanf scanf_s
#else
    #define CLEAR system("clear -x");
#endif

struct node1 {
    char value;
    struct node1* next;
};

struct SinglyLinkedList {
    struct node1* zeroptr;
    struct node1* currptr;
};

void init(struct SinglyLinkedList* list) {
    list->zeroptr = 0;
    list->currptr = 0;
}

void addElement(struct SinglyLinkedList* list, char value) {
    struct node1* newNode = (struct node1*) malloc(sizeof(struct node1));
    if(newNode == 0) {
        printf("Couldn't allocate memory for new node");
        return;
    }
    newNode->value = value;
    newNode->next = 0;
    if (list->currptr == 0) {
        list->currptr = newNode;
        list->zeroptr = newNode;
        return;
    }
    newNode->next = list->currptr->next;
    list->currptr->next = newNode;
}

void rmElement(struct SinglyLinkedList* list) {
    struct node1* toFree;
    if (list->currptr == 0) {
        printf("List is already empty");
        return;
    }
    if (list->currptr->next == 0) {
        toFree = list->currptr;
        list->currptr = 0;
        list->zeroptr = 0;
    } else {
        toFree = list->currptr->next;
        list->currptr->next = toFree->next;
    }
    free(toFree);
}

void clear(struct SinglyLinkedList* list) {
    list->currptr = list->zeroptr;
    while(list->currptr != 0) {
        rmElement(list);
    }
}

void moveptr(struct SinglyLinkedList* list) {
    if (list->currptr != 0 && list->currptr->next != 0) {
        list->currptr = list->currptr->next;;
    }
}

void printFrom(struct SinglyLinkedList list, struct node1* printFrom) {
    while (printFrom != 0) {
        if (printFrom == list.currptr) printf(">%c< ", printFrom->value);
        else printf("%c ", printFrom->value);
        printFrom = printFrom->next;
    }
    printf("\n");
}

void print(struct SinglyLinkedList list) {
    printFrom(list, list.zeroptr);
}

void printMenu() {
    printf("1) Initialize\n");
    printf("2) Clear list\n");
    printf("3) Is list empty\n");
    printf("4) Set pointer to 1 element\n");
    printf("5) Is pointer on the last element\n");
    printf("6) Move pointer to the right\n");
    printf("7) Show value after pointer\n");
    printf("8) Remove element after pointer\n");
    printf("9) Save value after pointer\n");
    printf("10) Edit element after pointer\n");
    printf("11) Add element after pointer\n");
    printf("12) Print list\n");
    printf("13) End work\n");
    printf("14) Stop program\n");
    printf("\nEnter command code: ");
}

void clearBuffer() {
    char c = getchar();
    while(c != '\n' && c != '\0' && c != EOF) {
        c = getchar();
    }
}

int main() {
    struct SinglyLinkedList list;
    int working = 0;
    int savedVal = 0;

    while(1) {
        printMenu();
        int cmd = 0;
        char c = getchar();
        while(c != '\n' && c != '\0' && c != EOF) {
            cmd = cmd * 10 + c - '0';
            c = getchar();
        }
        switch(cmd) {
        case 1:
            if (working) {
                printf("List is already initialized\n");
                break;
            }
            init(&list);
            working = 1;
            break;
        case 2:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            clear(&list);
            break;
        case 3:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.zeroptr == 0) printf("Yes\n");
            else printf("No\n");
            break;
        case 4:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            list.currptr = list.zeroptr;
            break;
        case 5:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->next == 0) printf("Yes\n");
            else printf("No\n");
            break;
        case 6:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            moveptr(&list);
            break;
        case 7:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->next == 0) printf("NULL\n");
            else printf("%c\n", list.currptr->next->value);
            break;
        case 8:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            rmElement(&list);
            break;
        case 9:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr != 0 && list.currptr->next != 0) savedVal = list.currptr->next->value;
            break;
        case 10:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            if (list.currptr == 0 || list.currptr->next == 0) printf("No element after pointer\n");
            else {
                printf("Enter new value: ");
                list.currptr->next->value = getchar();
                clearBuffer();
            }
            break;
        case 11:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            printf("Enter new element: ");
            addElement(&list, getchar());
            clearBuffer();
            break;
        case 12:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            break;
        case 13:
            if (!working) {
                printf("List is not initialized yet\n");
                break;
            }
            clear(&list);
            working = 0;
            break;
        case 14:
            goto label1;
            break;
        default:
            printf("No such command!\n");
        }
        if (working) print(list);
        printf("Press ENTER to continue");
        clearBuffer();
        CLEAR
    }
    label1:
    if (savedVal) printf("Saved value: %c\n", savedVal);
    return 0;
}
