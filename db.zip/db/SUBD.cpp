//

#include <stdio.h>
#include <string.h>
#define SIZE 50

struct ArtPiece {
    char name[SIZE];
    char artist[SIZE];
    int price;
};

ArtPiece db[SIZE];
int size = 0;

void addEntry(ArtPiece e) {
    db[size] = e;
    size++;
}

void rmEntry(int ordinal) {
    size--;
    db[ordinal] = db[size];
}

int strToInt(char* val, int* result) {
    *result = 0;
    for (int i = 0; i < SIZE; i++) {
        int m;
        switch (val[i]) {
        case '\0': return 1;
        case '0': m = 0;
            break;
        case '1': m = 1;
            break;
        case '2': m = 2;
            break;
        case '3': m = 3;
            break;
        case '4': m = 4;
            break;
        case '5': m = 5;
            break;
        case '6': m = 6;
            break;
        case '7': m = 7;
            break;
        case '8': m = 8;
            break;
        case '9': m = 9;
            break;
        default: return 0;
        }
        *result = *result * 10 + m;
    }
    return 1;
}

int scanInt() {
    int result;
    while (true) {
        char val[SIZE];
        scanf_s("%s", val, SIZE);
        if (strToInt(val, &result)) {
            return result;
        }
        printf_s("Expected integer here, type in integer\n");
    }
}

int scanEntry(ArtPiece* piece) {
    printf_s("Type in art piece's name\n");
    scanf_s("%s", piece->name, SIZE);
    if (!strcmp(piece->name, "end")) {
        return 0;
    }
    printf_s("Type in art piece's artist\n");
    scanf_s("%s", piece->artist, SIZE);
    if (!strcmp(piece->artist, "end")) {
        return 0;
    }
    printf_s("Type in art piece's price\n");
    piece->price = scanInt();
    return 1;
}

int add() {
    ArtPiece toAdd;
    if (scanEntry(&toAdd)) {
        addEntry(toAdd);
        return 1;
    }
    return 0;
}

void addM() {
    printf_s("Type in art piece.\n");
    add();
}

void inputFile() {
    size = 0;
    FILE* input;
    fopen_s(&input, "db.txt", "r");
    int k;
    fscanf_s(input, "%d", &k);
    for (int i = 0; i < k; i++) {
    	ArtPiece toAdd;
    	fscanf_s(input, "%s", toAdd.name, SIZE);
    	fscanf_s(input, "%s", toAdd.artist, SIZE);
    	fscanf_s(input, "%d", &toAdd.price);
    	addEntry(toAdd);
    }
    fclose(input);
}

void input() {
    size = 0;
    printf_s("Type in art pieces. Type \"end\" to finish\n");
    while (add()) {
        printf_s("Type in next art piece\n");
    }
}

void inMenu() {
    printf_s("1.From file\n2.Manually\n");
    int cmd = scanInt();
    switch (cmd) {
    case 1:
        inputFile();
        break;
    case 2:
        input();
        break;
    default:
        printf_s("Invalid command: expected from 1 to 2, encountered %d\n", cmd);
    }
}

void outputFile() {
    FILE* output;
    fopen_s(&output, "db.txt", "w");
    fprintf_s(output, "%d\n", size);
    for (int i = 0; i < size; i++) {
    	fprintf_s(output, "%s\n%s\n%d\n", db[i].name, db[i].artist, db[i].price);
    }
    fprintf_s(output, "\n\n");
    fclose(output);
}

void printHeader() {
	printf_s("%c", 201);
	for (int i = 0; i < 2; i++) {
		printf_s("%c", 205);
	}
    printf_s("%c", 203);
	for (int i = 0; i < SIZE; i++) {
        printf_s("%c", 205);
	}
    printf_s("%c", 203);
	for (int i = 0; i < SIZE; i++) {
        printf_s("%c", 205);
	}
    printf_s("%c", 203);
	for (int i = 0; i < 10; i++) {
        printf_s("%c", 205);
	}
	printf_s("%c\n", 187);

	printf_s("%c%2s%c%50s%c%50s%c%10s%c\n", 186, "#", 186, "Name", 186, "Artist", 186, "Price, $", 186);
}

void printEntry(int i, int ordinal) {
	printf_s("%c", 204);
	for (int i = 0; i < 2; i++) {
        printf_s("%c", 205);
	}
    printf_s("%c", 206);
	for (int i = 0; i < SIZE; i++) {
        printf_s("%c", 205);
	}
    printf_s("%c", 206);
	for (int i = 0; i < SIZE; i++) {
        printf_s("%c", 205);
	}
    printf_s("%c", 206);
	for (int i = 0; i < 10; i++) {
        printf_s("%c", 205);
	}
	printf_s("%c\n", 185);

	printf_s("%c%2d%c%50s%c%50s%c%10d%c\n", 186, i + 1, 186, db[ordinal].name, 186, db[ordinal].artist, 186, db[ordinal].price, 186);
}

void printfooter() {
	printf_s("%c", 200);
	for (int i = 0; i < 2; i++) {
        printf_s("%c", 205);
	}
    printf_s("%c", 202);
	for (int i = 0; i < SIZE; i++) {
        printf_s("%c", 205);
	}
    printf_s("%c", 202);
	for (int i = 0; i < SIZE; i++) {
        printf_s("%c", 205);
	}
	printf_s("%c", 202);
	for (int i = 0; i < 10; i++) {
        printf_s("%c", 205);
	}
	printf_s("%c\n", 188);
}

void output() {
    printHeader();
    for (int i = 0; i < size; i++) {
        printEntry(i, i);
    }
    printfooter();
}

void outMenu() {
    printf_s("1.To file\n2.To console\n");
    int cmd = scanInt();
    switch (cmd) {
    case 1:
        outputFile();
        break;
    case 2:
        output();
        break;
    default:
        printf_s("Invalid command: expected from 1 to 2, encountered %d\n", cmd);
    }
}

void rmByOrdinal() {
    printf_s("Type ordinal of entry to remove\n");
    int i = scanInt();
    if (i < 1 || i > size) {
    	printf_s("Invalid ordinal\n");
    	return;
    }
    i--;
    rmEntry(i);
}

void rmByName() {
    printf_s("Specify the name of art pieces to remove\n");
    char name[SIZE];
    scanf_s("%s", name, SIZE);
    for (int i = 0; i < size;) {
        if (!strcmp(db[i].name, name)) rmEntry(i);
        else i++;
    }
}

void rmByArtist() {
    printf_s("Specify the artist of art pieces to remove\n");
    char artist[SIZE];
    scanf_s("%s", artist, SIZE);
    for (int i = 0; i < size;) {
        if (!strcmp(db[i].artist, artist)) rmEntry(i);
        else i++;
    }
}

void rmByPrice() {
    printf_s("Specify the price of art pieces to remove\n");
    int price = scanInt();
    for (int i = 0; i < size;) {
        if (db[i].price == price) rmEntry(i);
        else i++;
    }
}

void rmMenu() {
    printf_s("1.By ordinal\n2.All with specified name\n3.All with specified artist\n4.All with specified price\n");
    int cmd = scanInt();
    switch (cmd) {
    case 1:
        rmByOrdinal();
        break;
    case 2:
        rmByName();
    	break;
    case 3:
        rmByArtist();
    	break;
    case 4:
        rmByPrice();
    	break;
    default:
        printf_s("Invalid command: expected from 1 to 4, encountered %d\n", cmd);
    }
}

void printByName() {
    printf_s("Specify the name of art pieces to select\n");
    char name[SIZE];
    scanf_s("%s", name, SIZE);
    printHeader();
    int k = 0;
    for (int i = 0; i < size; i++) {
        if (!strcmp(db[i].name, name)) {
        	printEntry(k, i);
        	k++;
        }
    }
    printfooter();
}

void printByArtist() {
    printf_s("Specify the artist of art pieces to select\n");
    char artist[SIZE];
    scanf_s("%s", artist, SIZE);
    printHeader();
    int k = 0;
    for (int i = 0; i < size; i++) {
        if (!strcmp(db[i].artist, artist)) {
        	printEntry(k, i);
        	k++;
        }
    }
    printfooter();
}

void printByPrice() {
    printf_s("Specify the price of art pieces to select\n");
    int price = scanInt();
    printHeader();
    int k = 0;
    for (int i = 0; i < size; i++) {
        if (db[i].price == price) {
        	printEntry(k, i);
        	k++;
        }
    }
    printfooter();
}

void searchMenu() {
    printf_s("1.By name\n2.By artist\n3.By price\n");
    int cmd = scanInt();
    switch (cmd) {
    case 1:
        printByName();
        break;
    case 2:
        printByArtist();
        break;
    case 3:
        printByPrice();
        break;
    default:
        printf_s("Invalid command: expected from 1 to 3, encountered %d\n", cmd);
    }
}

int cmp(int type, int a, int b) {
	switch(type) {
		case 1:
			return strcmp(db[a].name, db[b].name) > 0;
		case 2:
			return strcmp(db[a].artist, db[b].artist) > 0;
		case 3:
			return db[a].price > db[b].price;
		case 4:
			return strcmp(db[a].name, db[b].name) < 0;
		case 5:
			return strcmp(db[a].artist, db[b].artist) < 0;
		case 6:
			return db[a].price < db[b].price;
	}
}

void sort(int type) {
	for (int i = 0; i < size; i++) {
		int min = i;
		for (int j = i + 1; j < size; j++) {
			if (cmp(type, min, j)) min = j;
		}
		ArtPiece temp = db[i];
		db[i] = db[min];
		db[min] = temp;
	}
}

void sortMenu() {
    printf_s("1.By name ascending\n2.By artist ascending\n3.By price ascending\n4.By name descending\n5.By artist descending\n6.By price descending\n");
    int cmd = scanInt();
    switch (cmd) {
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
        sort(cmd);
        break;
    default:
        printf_s("Invalid command: expected from 1 to 6, encountered %d\n", cmd);
    }
}

int printMenu() {
    printf_s("1.Initialize\n2.Output\n3.Add\n4.Select\n5.Remove\n6.Sort\n7.End\n");
    int cmd = scanInt();
    switch (cmd) {
    case 1:
        inMenu();
        break;
    case 2:
        outMenu();
        break;
    case 3:
        addM();
        break;
    case 4:
        searchMenu();
        break;
    case 5:
        rmMenu();
        break;
    case 6:
        sortMenu();
        break;
    case 7:
        printf_s("Program finished\n");
        return 0;
    default:
        printf_s("Invalid command: expected from 1 to 7, encountered %d\n", cmd);
    }
    return 1;
}

int main() {
    while (printMenu());
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
