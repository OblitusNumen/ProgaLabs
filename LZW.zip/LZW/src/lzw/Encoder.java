package lzw;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

public class Encoder {
    public static final String INITIAL_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ `_±“”‘’–—@#$%^&*()+{}[]<>~|/\\,.?!:;\"'-\n" +
            "\t1234567890abcdefghijklmnopqrstuvwxyzàìùèòÀÌÙÈÒ¯¿¡⸘→←āīūēōĀĪŪĒŌãĩũõÃĨŨÕ";
    public static final int ALPHABET_LENGTH = INITIAL_ALPHABET.length() - 1;

    public static void main(String[] args) throws Exception {
        String inF = Main.dir + args[0];
        String outF = Main.dir + args[1];
        String in;
        try (FileInputStream fileInputStream = new FileInputStream(inF)) {
            in = new String(fileInputStream.readAllBytes());
        }
        for (int i = 0; i < in.length(); i++) {
            if (INITIAL_ALPHABET.indexOf(in.charAt(i)) < 0) throw new NotEncodableException(in.charAt(i));
        }

        char marker = analyze(in);
        String alphabet = INITIAL_ALPHABET.replace(Character.toString(marker), "");

        StringBuilder out = new StringBuilder(Character.toString(marker));
        for (int i = 0; i < in.length(); i++) {
            String buffer = "";
            int j = 0;
            while (in.substring(0, i).contains(buffer) && i + j < in.length()) {
                buffer += in.charAt(i + j);
                j++;
                if (j >= ALPHABET_LENGTH) break;
            }
            String original = buffer.substring(0, buffer.length() - 1);
            int index = in.indexOf(original);
            String replacement = marker + getAlphaIndex(index, alphabet) + alphabet.charAt(j - 1) + marker;
            if (original.length() <= replacement.length()) {
                char c = buffer.charAt(0);
                out.append(c == marker ? "" + c + c : c);
                continue;
            }
            out.append(replacement);
            i += original.length() - 1;
        }

        try (FileOutputStream fileOutputStream = new FileOutputStream(outF)) {
            fileOutputStream.write(out.toString().getBytes());
        }
    }

    private static char analyze(String in) {
        Map<Character, Integer> amounts = new HashMap<>();
        for (int i = 0; i < INITIAL_ALPHABET.length(); i++) {
            amounts.put(INITIAL_ALPHABET.charAt(i), 0);
        }

        for (int i = 0; i < in.length(); i++) {
            amounts.put(in.charAt(i), amounts.get(in.charAt(i)) + 1);
        }

        char marker = INITIAL_ALPHABET.charAt(0);
        int min = amounts.get(marker);
        for (int i = 1; i < INITIAL_ALPHABET.length(); i++) {
            if (min == 0) break;
            if (amounts.get(INITIAL_ALPHABET.charAt(i)) < min) {
                marker = INITIAL_ALPHABET.charAt(i);
                min = amounts.get(marker);
            }
        }
        return marker;
    }

    public static String getAlphaIndex(int index, String alphabet) {
        StringBuilder result = new StringBuilder();
        while (index != 0) {
            result.insert(0, alphabet.charAt(index % ALPHABET_LENGTH));
            index /= ALPHABET_LENGTH;
        }
        return result.toString();
    }
}
