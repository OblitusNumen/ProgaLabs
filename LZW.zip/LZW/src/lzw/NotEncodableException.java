package lzw;

public class NotEncodableException extends IllegalArgumentException {
    public NotEncodableException(char c) {
        super(String.format("The alphabet does not contain character '%c'!!!\nAlphabet:%s", c, Encoder.INITIAL_ALPHABET));
    }
}
