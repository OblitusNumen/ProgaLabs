package lzw;

public class NotDecodableException extends IllegalArgumentException {
    public NotDecodableException() {
        super("Malformed message");
    }

    public NotDecodableException(char c) {
        super(String.format("The alphabet does not contain character '%c'!!!\nAlphabet:%s", c, Encoder.INITIAL_ALPHABET));
    }

    public NotDecodableException(Throwable cause) {
        super(cause);
    }
}
