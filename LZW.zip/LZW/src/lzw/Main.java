package lzw;

import java.io.File;
import java.util.*;

import static lzw.Encoder.INITIAL_ALPHABET;

public class Main {
    public static final String dir = System.getProperty("user.dir") + File.separator;

    public static void main(String[] args) {
        checkAlphabetValid();
        System.out.println("Usage:\n" +
                "    type \"stop\" to finish\n" +
                "    type \"e <input file> <output file>\" to encode\n" +
                "    type \"d <input file> <output file>\" to decode");
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) try {
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("stop")) break;
                String[] arguments = input.split("[ \t]");
                if (arguments[0].equalsIgnoreCase("e")) {
                    Encoder.main(new String[]{arguments[1], arguments[2]});
                } else if (arguments[0].equalsIgnoreCase("d")) {
                    Decoder.main(new String[]{arguments[1], arguments[2]});
                } else if (arguments[0].equalsIgnoreCase("c")) {
                    Check.main(new String[]{arguments[1], arguments[2], arguments[3], arguments[4]});
                } else {
                    System.out.println("No such command!");
                    continue;
                }
                System.out.println("Done!");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void checkAlphabetValid() {
        Set<Character> characters = new HashSet<>();
        for (int i = 0; i < INITIAL_ALPHABET.length(); i++) {
            if (characters.contains(INITIAL_ALPHABET.charAt(i))) throw new RuntimeException("Alphabet must not contain character more than 1 time!");
            characters.add(INITIAL_ALPHABET.charAt(i));
        }
    }
}
