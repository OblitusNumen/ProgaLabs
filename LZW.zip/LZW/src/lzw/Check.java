package lzw;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Random;

public class Check {
    public static void main(String[] args) throws Exception {
        String inEF = Main.dir + args[0];
        String outEF = Main.dir + args[1];
        String outDF = Main.dir + args[2];
        String checkF = Main.dir + args[3];

        File file = new File(inEF);
        if (!file.exists()) {
            try (FileOutputStream fileOutputStream = new FileOutputStream(file)) {
                Random random = new Random();
                StringBuilder in = new StringBuilder();
                for (int i = 0; i < 1000; i++) {
                    in.append(Encoder.getAlphaIndex(Math.abs(random.nextInt()), Encoder.INITIAL_ALPHABET));
                }
                fileOutputStream.write(in.toString().getBytes());
            }
        }

        Encoder.main(new String[]{new File(inEF).getName(), new File(outEF).getName()});
        Decoder.main(new String[]{new File(outEF).getName(), new File(outDF).getName()});
        try (FileInputStream fileInputStream = new FileInputStream(inEF)) {
            try (FileInputStream fileInputStream2 = new FileInputStream(outEF)) {
                try (FileInputStream fileInputStream3 = new FileInputStream(outDF)) {
                    try (FileOutputStream fileOutputStream = new FileOutputStream(checkF)) {
                        fileOutputStream.write((new String(fileInputStream.readAllBytes()) + "\n" +
                                new String(fileInputStream2.readAllBytes()) + "\n" +
                                new String(fileInputStream3.readAllBytes())).getBytes());
                    }
                }
            }
        }

        try (FileInputStream fileInputStream = new FileInputStream(inEF)) {
            try (FileInputStream inputStream = new FileInputStream(outDF)) {
                System.out.println(new String(fileInputStream.readAllBytes()).equals(new String(inputStream.readAllBytes())));
            }
        }
    }
}
