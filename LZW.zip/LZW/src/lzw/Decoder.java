package lzw;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import static lzw.Encoder.*;

public class Decoder {
    public static void main(String[] args) throws Exception {
        String inF = Main.dir + args[0];
        String outF = Main.dir + args[1];
        String in;
        try (FileInputStream fileInputStream = new FileInputStream(inF)) {
            in = new String(fileInputStream.readAllBytes());
        }
        for (int i = 0; i < in.length(); i++) {
            if (INITIAL_ALPHABET.indexOf(in.charAt(i)) < 0) throw new NotDecodableException(in.charAt(i));
        }

        char marker = in.charAt(0);
        in = in.substring(1);
        String alphabet = INITIAL_ALPHABET.replace(Character.toString(marker), "");

        StringBuilder out = new StringBuilder();

        try {
            while (!in.isEmpty()) {
                int index = in.indexOf(marker);
                if (index < 0) {
                    out.append(in);
                    break;
                }
                int secIndex = in.substring(index + 1).indexOf(marker) + index + 1;
                if (secIndex - 1 == index) {
                    out.append(in, 0, secIndex);
                    in = in.substring(secIndex + 1);
                    continue;
                }
                String alphaIndex = in.substring(index + 1, secIndex - 1);
                int alphaIndex1 = getAlphaIndex(alphaIndex, alphabet);
                out.append(in, 0, index).append(out.substring(alphaIndex1, alphaIndex1 + alphabet.indexOf(in.charAt(secIndex - 1))));
                in = in.substring(secIndex + 1);
            }
        } catch (Exception e) {
            throw new NotDecodableException(e);
        }
        try (FileOutputStream fileOutputStream = new FileOutputStream(outF)) {
            fileOutputStream.write(out.toString().getBytes());
        }
    }

    public static int getAlphaIndex(String alphaIndex, String alphabet) {
        int i = 0;
        for (int j = 0; j < alphaIndex.length(); j++) {
            i = i * ALPHABET_LENGTH + alphabet.indexOf(alphaIndex.charAt(j));
        }
        return i;
    }
}
